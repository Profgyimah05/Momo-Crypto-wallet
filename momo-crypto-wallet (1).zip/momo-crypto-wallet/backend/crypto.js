const axios = require('axios');

async function createCryptoPayout(address, amount, currency) {
  const res = await axios.post('https://api.nowpayments.io/v1/payouts', {
    address, amount, currency
  }, {
    headers: { 'x-api-key': process.env.NOWPAYMENTS_API_KEY }
  });
  return res.data;
}

module.exports = { createCryptoPayout };