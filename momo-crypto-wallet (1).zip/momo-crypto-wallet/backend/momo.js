const axios = require('axios');

async function getAccessToken() {
  const res = await axios.post(`${process.env.MTN_API_BASE}/v1/oauth/token`, {}, {
    headers: { 'Ocp-Apim-Subscription-Key': process.env.MTN_SUBSCRIPTION_KEY }
  });
  return res.data.access_token;
}

async function createDepositRequest(amount, msisdn, externalId) {
  const token = await getAccessToken();
  const res = await axios.post(`${process.env.MTN_API_BASE}/collection/v1_0/requesttopay`, {
    amount: amount.toString(),
    currency: 'EUR',
    externalId,
    payer: { partyIdType: 'MSISDN', partyId: msisdn },
    payerMessage: 'Deposit to wallet',
    payeeNote: 'Web app deposit'
  }, {
    headers: {
      Authorization: `Bearer ${token}`,
      'X-Target-Environment': 'sandbox',
      'Ocp-Apim-Subscription-Key': process.env.MTN_SUBSCRIPTION_KEY
    }
  });
  return res.data;
}

async function momoWebhook(req, res) {
  console.log('MTN webhook:', req.body);
  res.status(200).send();
}

module.exports = { createDepositRequest, momoWebhook };