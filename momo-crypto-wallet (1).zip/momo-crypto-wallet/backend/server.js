const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const { createDepositRequest, momoWebhook } = require('./momo');
const { createCryptoPayout } = require('./crypto');

const app = express();
app.use(cors());
app.use(bodyParser.json());

app.post('/api/deposit', async (req, res) => {
  const { userId, amount, phone } = req.body;
  const result = await createDepositRequest(amount, phone, userId);
  res.json(result);
});

app.post('/api/webhook/momo', momoWebhook);

app.post('/api/withdraw', async (req, res) => {
  const { userId, amount, address, currency } = req.body;
  const result = await createCryptoPayout(address, amount, currency);
  res.json(result);
});

app.listen(4000, () => console.log('Backend running on port 4000'));