import React, { useState } from 'react';
import axios from 'axios';

function App() {
  const [amount, setAmount] = useState(0);
  const [phone, setPhone] = useState('');
  const [cryptoAddress, setCryptoAddress] = useState('');
  const [currency, setCurrency] = useState('usdt');

  const deposit = async () => {
    const res = await axios.post('/api/deposit', { userId: 1, amount, phone });
    console.log('Deposit:', res.data);
  };

  const withdraw = async () => {
    const res = await axios.post('/api/withdraw', { userId: 1, amount, address: cryptoAddress, currency });
    console.log('Withdraw:', res.data);
  };

  return (
    <div className="p-6">
      <h1 className="text-xl font-bold">Wallet App</h1>
      <div className="mt-4">
        <h2 className="font-semibold">Deposit via MTN MoMo</h2>
        <input type="text" placeholder="Phone" value={phone} onChange={e => setPhone(e.target.value)} />
        <input type="number" placeholder="Amount" value={amount} onChange={e => setAmount(e.target.value)} />
        <button onClick={deposit}>Deposit</button>
      </div>
      <div className="mt-4">
        <h2 className="font-semibold">Withdraw to Crypto</h2>
        <input type="text" placeholder="Crypto Address" value={cryptoAddress} onChange={e => setCryptoAddress(e.target.value)} />
        <select value={currency} onChange={e => setCurrency(e.target.value)}>
          <option value="usdt">USDT</option>
          <option value="btc">BTC</option>
          <option value="eth">ETH</option>
        </select>
        <input type="number" placeholder="Amount" value={amount} onChange={e => setAmount(e.target.value)} />
        <button onClick={withdraw}>Withdraw</button>
      </div>
    </div>
  );
}

export default App;