# MoMo Crypto Wallet

This project lets you deposit with MTN Mobile Money and withdraw in crypto.

## One-click Deploy

[![Deploy to Heroku](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy)

## Setup

1. Create accounts on:
   - [MTN MoMo Developer](https://momodeveloper.mtn.com)
   - [NOWPayments](https://nowpayments.io)
2. Get your API keys and paste them during deploy.
3. After deploy, open your app and test deposits/withdrawals.

---
